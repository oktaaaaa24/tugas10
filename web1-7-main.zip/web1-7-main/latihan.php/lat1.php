<!DOCTYPE html>
<html>
<head>
    <title>Latihan 1</title>
</head>
<body>

<h2>Bilangan Genap 1–10</h2>
<?php
for ($i = 1; $i <= 10; $i++) {
    if ($i % 2 == 0) {
        echo $i . " ";
    }
}
?>

</body>
</html>